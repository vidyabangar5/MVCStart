﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EmployeeExampleForViewBag.Models;

namespace EmployeeExampleForViewBag.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index(string FName, string LName, int Age)
        {
            Employee emp = new Employee();
            emp.EmpFirstname = FName;
            emp.EmpLastname = LName;
            emp.EmpAge = Age;
            ///// ViewBag  ---------------- ViewBag.data = emp;
            return View(emp);
        }
        public ActionResult ListExample(string FName, string LName, int Age)
        {
            List<Employee> list = new List<Employee>();
            Employee emp = new Employee();
            emp.EmpFirstname = FName;
            emp.EmpLastname = LName;
            emp.EmpAge = Age;

            Employee emp2 = new Employee();
            emp2.EmpFirstname = FName;
            emp2.EmpLastname = LName;
            emp2.EmpAge = Age;

            list.Add(emp);
            list.Add(emp2);

            return View(list);
        }
    }
}