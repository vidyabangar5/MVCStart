﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeExampleForViewBag.Models
{
    public class Employee
    {
        public string EmpFirstname { get; set; }
        public string EmpLastname { get; set; }
        public int EmpAge { get; set; }
    }
}